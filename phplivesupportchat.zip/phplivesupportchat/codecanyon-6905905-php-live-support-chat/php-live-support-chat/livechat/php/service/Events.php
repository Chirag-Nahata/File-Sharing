<?php

class Events extends Service
{
}

?>
